<?php 

$db["host"]="localhost";
$db["user"]="id19392144_username";
$db["pass"]="password1234_A";
$db["database"]="id19392144_cms";

foreach($db as $key=> $value)
{
    
    define(strtoupper($key),$value);
   
}
$connection = mysqli_connect(HOST,USER,PASS,DATABASE);
// if($connection)
// {
//     echo "i'm superman";
// }

?>