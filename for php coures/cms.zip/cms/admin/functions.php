
<?php

function confirm($result)
{
    global $connection;
    if(!$result){
        die("we fucked up ".mysqli_error($connection));
    }
}

function Category_insertion()
{
    global $connection;
    if (isset($_POST['submit'])) {
        $category_title = $_POST['category_title'];
        if ($category_title == "" || empty($category_title)) {
            echo " This can't be empty ";
        } else {
            $query = " insert into category(category_title) value('{$category_title}') ";
            $myinsertion = mysqli_query($connection, $query);
            if (!$myinsertion) {
                die("we fucked up " . mysqli_error($connection));
            }
        }
    }
}

function findAllCategories()
{
    global $connection;
    $query = " select * from category ";
    $select_mycategory = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($select_mycategory)) {
        $category_id    = $row["category_id"];
        $category_title = $row["category_title"];
        echo "<tr>";
        echo "<td>{$category_title}</td>";
        echo "<td>{$category_id}</td>";
        echo "<td><a href='categories.php?delete={$category_id}'>Delete</a></td>";
        echo "<td><a href='categories.php?Edit={$category_id}'>Edit</a></td>";
        echo "</tr>";
    }
}
function delete()
{
    global $connection;
    if (isset($_GET["delete"])) {
        $category_id = $_GET["delete"];
        $query = " delete from category where category_id = {$category_id}";
        $delete_query = mysqli_query($connection, $query);
        header('Location: categories.php');
    }

}
function update_categories()
{
    global $connection;
    if (isset($_POST["update"])) {
        $category_title = $_POST["category_title"];
        $category_id=$_GET["Edit"];
        $query = " update category set category_title='{$category_title}' where category_id = {$category_id}";
        $update_query = mysqli_query($connection, $query);
        if (!isset($update_query)) {
            die("we are died");
        }
    }

}

// function redirect($location){
//      return header( header:"Location:".$location );
// }

function users_online(){
    if(isset($_GET['onlineusers']))
    {
    global $connection;
    if(!$connection)
    {
        session_start();
        include"../includes/db.php";
    }
    $session=session_id();
    $time=time();
    $time_out_in_sec=05;
    $time_out= $time - $time_out_in_sec;

    $query="SELECT * FROM users_online WHERE session = '$session' ";
    $sendQuery=mysqli_query($connection,$query);
    $count=mysqli_num_rows($sendQuery);
    if($count== NULL)
    {
        mysqli_query($connection,"INSERT INTO users_online(session,time) VALUES('$session','$time') ");
    }
    else
    {
        mysqli_query($connection,"UPDATE users_online SET time='$time' WHERE session ='$session'");
    }
    $user_online=mysqli_query($connection,"SELECT * FROM users_online where time > '$time_out'");
    echo $counter_user=mysqli_num_rows($user_online);
}  }
users_online();


function escape($string)
{
    global $connection;
    return mysqli_real_escape_string($connection,trim($string));
}
?> 